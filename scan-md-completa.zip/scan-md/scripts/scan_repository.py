"""Read-only triage. Indicators require human/agent review; this is not a malware verdict."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat

EXCLUDED = {".git", "node_modules", ".venv", "venv", "__pycache__"}
RULES = {
    "instruction-redirection": r"ignore (?:all |any )?(?:previous|prior|system) instructions|ignore (?:as )?instru[cç][oõ]es anteriores",
    "concealment": r"do not (?:tell|inform|notify) (?:the )?user|hide (?:this|these) (?:change|action)|n[aã]o (?:avise|informe) (?:o )?usu[aá]rio",
    "safety-bypass": r"dangerously-bypass|bypassPermissions|disable.{0,30}sandbox|desativ.{0,30}(?:sandbox|prote[cç])",
    "global-agent-configuration": r"(?:~/|[/\\])\.codex[/\\]config\.toml|(?:~/|[/\\])\.claude[/\\]settings\.json",
    "api-routing": r"ANTHROPIC_BASE_URL|OPENAI_BASE_URL|OPENAI_API_BASE|model_provider|base_url",
    "credential-access": r"\.ssh[/\\]|\.aws[/\\]|auth\.json|credentials\.json|(?:read|send|upload|exfiltrat).{0,60}(?:token|password|cookie|secret|senha)",
    "remote-execution": r"(?:curl|wget|Invoke-WebRequest|iwr)\b.{0,240}(?:\|\s*(?:bash|sh|iex|Invoke-Expression)|;\s*(?:bash|sh))|(?:FromBase64String|EncodedCommand)\b",
    "persistence": r"\b(?:launchctl|schtasks|crontab|New-ScheduledTask|Register-ScheduledTask)\b|CurrentVersion[/\\]+Run",
    "mcp-configuration": r"\bmcpServers\b|\bmcp_servers\b",
    "install-lifecycle": r'["\x27](?:preinstall|postinstall|prepare|install)["\x27]\s*:|\bbuild-backend\b|cmdclass\s*=',
}

def is_downloads_path(path, downloads_roots=()):
    # Component checks also cover redirected folders named Downloads.
    value = Path(path)
    if any(part.casefold() == "downloads" for part in value.parts):
        return True
    normalized = os.path.normcase(os.path.abspath(value))
    for root in downloads_roots:
        candidate = os.path.normcase(os.path.abspath(root))
        try:
            if os.path.commonpath([normalized, candidate]) == candidate:
                return True
        except ValueError:
            continue
    return False

def is_link(path, info):
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )

def scan_repository(root, downloads_roots=(), max_entries=10000,
                    max_file_bytes=2 * 1024 * 1024, max_total_bytes=64 * 1024 * 1024):
    requested = Path(root).absolute()
    defaults = [Path(os.environ["USERPROFILE"]) / "Downloads"] if os.environ.get("USERPROFILE") else []
    downloads_roots = [*defaults, *downloads_roots]
    report = {
        "root": str(requested), "status": "review-required",
        "installation_authorized": False, "complete": True,
        "limits": {"max_entries": max_entries, "max_file_bytes": max_file_bytes,
                   "max_total_bytes": max_total_bytes},
        "files": [], "findings": [], "gaps": [], "excluded": [],
        "snapshot_sha256": None,
        "scope": "Local inventory and lexical indicators only; no dependencies downloaded or executed.",
    }
    def gap(file, reason):
        report["complete"] = False
        report["gaps"].append({"file": str(file), "reason": reason})

    try:
        info = requested.lstat()
        if is_link(requested, info):
            gap(".", "link-not-followed")
            return report
        actual = requested.resolve(strict=True)
        report["root"] = str(actual)
        if is_downloads_path(requested, downloads_roots) or is_downloads_path(actual, downloads_roots):
            report["status"] = "blocked"
            gap(".", "downloads-workspace")
            return report
        if not stat.S_ISDIR(info.st_mode):
            gap(".", "not-a-directory")
            return report
    except OSError:
        gap(".", "root-unavailable")
        return report

    entries_seen = 0
    total_bytes = 0
    pending = [(actual, 0)]
    while pending:
        folder, depth = pending.pop()
        if depth > 32:
            gap(folder.relative_to(actual).as_posix(), "depth-limit")
            continue
        try:
            with os.scandir(folder) as listing:
                children = sorted(listing, key=lambda entry: entry.name)
        except OSError:
            gap(folder.relative_to(actual).as_posix(), "directory-unreadable")
            continue
        for entry in children:
            entries_seen += 1
            if entries_seen > max_entries:
                gap(".", "entry-limit")
                pending.clear()
                break
            path = Path(entry.path)
            rel = path.relative_to(actual).as_posix()
            try:
                info = path.lstat()
                if is_link(path, info):
                    gap(rel, "link-not-followed")
                    continue
                if not path.resolve(strict=True).is_relative_to(actual):
                    gap(rel, "path-outside-root")
                    continue
                if stat.S_ISDIR(info.st_mode):
                    if path.name in EXCLUDED:
                        report["excluded"].append(rel)
                    else:
                        pending.append((path, depth + 1))
                    continue
                if not stat.S_ISREG(info.st_mode):
                    gap(rel, "special-file-not-read")
                    continue
                if info.st_size > max_file_bytes:
                    gap(rel, "file-size-limit")
                    continue
                if total_bytes + info.st_size > max_total_bytes:
                    gap(rel, "total-byte-limit")
                    continue
                with path.open("rb") as handle:
                    data = handle.read(max_file_bytes + 1)
                if len(data) > max_file_bytes:
                    gap(rel, "file-size-limit")
                    continue
                total_bytes += len(data)
                after = path.lstat()
                if is_link(path, after) or (info.st_ino, info.st_size, info.st_mtime_ns) != (
                        after.st_ino, after.st_size, after.st_mtime_ns):
                    gap(rel, "file-changed-during-read")
                    continue
            except OSError:
                gap(rel, "file-unreadable")
                continue
            digest = hashlib.sha256(data).hexdigest()
            record = {"path": rel, "sha256": digest, "bytes": len(data)}
            try:
                if data.startswith((b"\xff\xfe", b"\xfe\xff")):
                    text = data.decode("utf-16")
                else:
                    if b"\x00" in data:
                        raise UnicodeError("binary")
                    text = data.decode("utf-8-sig")
                record.update(kind="text", review="lexical-only")
            except UnicodeError:
                record.update(kind="binary", review="not-inspected")
                report["files"].append(record)
                continue
            report["files"].append(record)
            for rule, pattern in RULES.items():
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    # Do not print source lines: they may contain tokens or terminal escapes.
                    report["findings"].append({
                        "file": rel, "line": text.count("\n", 0, match.start()) + 1,
                        "rule": rule, "severity": "review", "sha256": digest,
                    })

    report["files"].sort(key=lambda record: record["path"])
    manifest = json.dumps({"files": report["files"], "gaps": report["gaps"],
                           "excluded": sorted(report["excluded"])},
                          sort_keys=True, ensure_ascii=True).encode("utf-8")
    report["snapshot_sha256"] = hashlib.sha256(manifest).hexdigest()
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", help="Repository directory to inspect, never execute.")
    parser.add_argument("--downloads-root", action="append", default=[],
                        help="Additional actual Downloads location, including redirected/localized folders.")
    args = parser.parse_args()
    report = scan_repository(args.root, downloads_roots=args.downloads_root)
    print(json.dumps(report, ensure_ascii=True, indent=2))
    # 0 means the inventory finished, never permission to install.
    return 2 if report["status"] == "blocked" else (3 if not report["complete"] else 0)

if __name__ == "__main__":
    raise SystemExit(main())
